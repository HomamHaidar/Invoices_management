<!DOCTYPE html>
<html>
<head>
    <title>Login - Invoices Website</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            background-color: #0000;
        }
        .logo {
            display: flex;
            justify-content: center;
            margin-top: 50px;
            margin-bottom: 50px;
        }
        .card {
            margin-top: 50px;
            margin-bottom: 50px;
            max-width: 400px;
            margin-left: auto;
            margin-right: auto;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.3);
        }
        .card-header {
            background-color: #1a2a57;
            color: #fff;
            text-align: center;
            font-weight: bold;
            font-size: 24px;
            border-bottom: none;
        }
        .card-body {
            padding: 30px;
            background-color: #fff;
            border-radius: 5px;
            border-top-left-radius: 0;
            border-top-right-radius: 0;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-control {
            height: 50px;
            font-size: 18px;
            border-radius: 5px;
            padding: 10px;
            box-shadow: none;
            border: 1px solid #ccc;
        }
        .form-control:focus {
            border-color: #007bff;
            box-shadow: none;
        }
        .form-control::-webkit-input-placeholder {
            color: #aaa;
        }
        .form-control:-ms-input-placeholder {
            color: #aaa;
        }
        .form-control::-ms-input-placeholder {
            color: #aaa;
        }
        .form-control::placeholder {
            color: #aaa;
        }
        .btn {
            font-size: 18px;
            border-radius: 5px;
            padding: 10px 20px;
            background-color: #1a2a57;
            color: #fff;
            border: none;
            box-shadow: none;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #1a2a80;
        }
        .forgot-password {
            font-size: 14px;
            color: #007bff;
        }
        .forgot-password:hover {
            color: #0069d9;
            text-decoration: none;
        }
    </style>
</head>
<body>
<div class="logo">
   <img src="<?php echo e(URL::asset('assets/img/brand/fatora.png')); ?>" class="sign-favicon ht-40" style="width: 568px; height: 175px" alt="logo">
</div>
<form method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo csrf_field(); ?>
    <div class="card">
        <div class="card-header">
            Login
        </div>
        <div class="card-body">
            <form action="login.php" method="post">
                <div class="form-group">
                    <label for="email">Email address</label>
                    <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Enter email" required autofocus autocomplete="email">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                         <strong><?php echo e($message); ?></strong>
                     </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" name="password" placeholder="Password" required autocomplete="current-password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group row">
                    <div class="col-md-6 offset-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="remember">
                             <?php echo e(__('remember me')); ?>

                            </label>
                        </div>
                    </div>
                </div>

                <button type="submit"  class="btn btn-primary btn-block">
                    <?php echo e(__('LOGIN')); ?>

                </button>

            </form>
        </div>
    </div>
</form>

</body>
</html>
























































































<?php /**PATH C:\homam\web\laravel\PROJECTS\Invoices\resources\views/auth/login.blade.php ENDPATH**/ ?>