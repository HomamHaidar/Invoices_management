<?php echo e($slot); ?>

<?php /**PATH C:\homam\web\laravel\PROJECTS\Invoices\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>