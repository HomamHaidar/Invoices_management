<!-- Footer opened -->
	<div class="main-footer ht-40">
		<div class="container-fluid pd-t-0-f ht-100p">
			<span>Copyright © 2020 <a href="#">homam cc</a>. Designed by <a>homam haidar</a> All rights reserved.</span>
		</div>
	</div>
<!-- Footer closed -->
<?php /**PATH C:\homam\web\laravel\PROJECTS\Invoices\resources\views/layouts/footer.blade.php ENDPATH**/ ?>