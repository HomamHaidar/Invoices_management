<x-mail::message>
# تم اضافة فاتورة
مرحبا بك

<x-mail::button :url="'http://127.0.0.1:8000/InvoicesDetails/'. $id">
عرض الفاتورة
</x-mail::button>

شكرا لثقتك عزيزي<br>
Homam Nizar Haidar
</x-mail::message>


